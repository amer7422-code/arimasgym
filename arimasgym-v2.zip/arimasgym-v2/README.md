# Arimas Gym API

نظام إدارة نادي رياضي: NestJS + Prisma + PostgreSQL.

## التشغيل
```bash
npm install
cp .env.example .env        # املأ DATABASE_URL والأسرار (openssl rand -base64 48)
npx prisma migrate dev --name init
npm run prisma:seed         # ينشئ حساب Admin والخطط الأساسية
npm run start:dev
```

## المسارات
| Method | Path | الصلاحية |
|---|---|---|
| POST | /auth/register, /auth/login, /auth/refresh | عام (حد 5 طلبات/دقيقة) |
| POST | /auth/logout | مسجّل دخول |
| GET/PATCH | /members/me | مسجّل دخول |
| GET | /members, /members/:id | ADMIN, TRAINER |
| GET | /plans | مسجّل دخول |
| POST | /plans | ADMIN |
| GET | /subscriptions/me | مسجّل دخول |
| POST | /subscriptions, PATCH /subscriptions/:id/cancel | ADMIN |
| POST | /attendance/check-in, GET /attendance | ADMIN, TRAINER |
| GET | /attendance/me | مسجّل دخول |

## قرارات أمنية
- كل المسارات محمية افتراضياً (Guard عام)، والعام يحتاج `@Public()` صراحةً.
- كلمات المرور بـ bcrypt (12 rounds)، والـ Refresh Token يُحفظ كـ SHA-256 ويُدوَّر عند كل تجديد؛ إعادة استخدام توكن قديم تُنهي الجلسة.
- الدور يُقرأ من قاعدة البيانات في كل طلب، فتعطيل الحساب يسري فوراً.
- التسجيل العام ينشئ MEMBER فقط. حسابات ADMIN وTRAINER تُنشأ عبر الـ seed أو مباشرة في القاعدة.
- التحقق من المدخلات `whitelist + forbidNonWhitelisted`، وhelmet وCORS محدد بقائمة، والتطبيق لا يقلع بأسرار ضعيفة.

## ملاحظات
- جلسة واحدة نشطة لكل مستخدم (تسجيل الدخول من جهاز آخر يُبطل السابق).
- حالة الاشتراك تُحسب من `endDate` عند الفحص؛ لا توجد مهمة مجدولة لتحديثها.

## النشر (Render + arimasgym.com)
1. أنشئ PostgreSQL (Render أو Neon) وانسخ `DATABASE_URL`.
2. Render → New → Blueprint → اختر المستودع (يقرأ `render.yaml`)، ثم الصق `DATABASE_URL`.
3. بعد أول نشر شغّل الـ seed مرة واحدة من Shell الخدمة: `ADMIN_EMAIL=... ADMIN_PASSWORD=... npx prisma db seed` (يحتاج ts-node، لذا يُشغَّل محلياً أو بـ `--include=dev`).
4. DNS في Namecheap: سجل `CNAME` باسم `api` يشير إلى عنوان `*.onrender.com` الذي تعرضه Render.
5. تأكد من `https://api.arimasgym.com/health` يرجع `{"status":"ok"}`.
6. `CORS_ORIGINS` يجب أن يطابق نطاق الواجهة بالضبط (مع https وبدون `/` في النهاية).

الـ CI في `.github/workflows/ci.yml` يبني ويختبر عند كل push وPR.
