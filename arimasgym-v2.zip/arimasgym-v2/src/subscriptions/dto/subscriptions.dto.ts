import { IsDateString, IsInt, IsNotEmpty, IsNumber, IsOptional, IsString, IsUUID, Max, MaxLength, Min } from 'class-validator';

export class CreatePlanDto {
  @IsString() @IsNotEmpty() @MaxLength(50)
  name: string;

  @IsInt() @Min(1) @Max(3650)
  durationDays: number;

  @IsNumber({ maxDecimalPlaces: 2 }) @Min(0)
  price: number;
}

export class CreateSubscriptionDto {
  @IsUUID() memberId: string;
  @IsUUID() planId: string;
  @IsOptional() @IsDateString() startDate?: string;
}
