import { IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';

export class UpdateMemberDto {
  @IsOptional() @IsString() @IsNotEmpty() @MaxLength(100)
  fullName?: string;

  @IsOptional() @IsString() @MaxLength(30)
  phone?: string;
}
