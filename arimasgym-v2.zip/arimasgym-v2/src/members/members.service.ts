import { Injectable, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PaginationDto } from '../common/pagination.dto';
import { PrismaService } from '../prisma/prisma.service';
import { UpdateMemberDto } from './dto/update-member.dto';

// Explicit select: passwordHash and refreshTokenHash can never leak through this module.
const SELECT = {
  id: true,
  fullName: true,
  phone: true,
  createdAt: true,
  user: { select: { email: true, role: true, isActive: true } },
} satisfies Prisma.MemberSelect;

@Injectable()
export class MembersService {
  constructor(private prisma: PrismaService) {}

  async findAll({ page, limit }: PaginationDto) {
    const [items, total] = await this.prisma.$transaction([
      this.prisma.member.findMany({
        select: SELECT,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      this.prisma.member.count(),
    ]);
    return { items, total, page, limit };
  }

  async findOne(id: string) {
    const member = await this.prisma.member.findUnique({ where: { id }, select: SELECT });
    if (!member) throw new NotFoundException('Member not found');
    return member;
  }

  async findByUser(userId: string) {
    const member = await this.prisma.member.findUnique({ where: { userId }, select: SELECT });
    if (!member) throw new NotFoundException('Member profile not found');
    return member;
  }

  async updateMe(userId: string, dto: UpdateMemberDto) {
    try {
      return await this.prisma.member.update({ where: { userId }, data: dto, select: SELECT });
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === 'P2025') {
        throw new NotFoundException('Member profile not found');
      }
      throw e;
    }
  }
}
