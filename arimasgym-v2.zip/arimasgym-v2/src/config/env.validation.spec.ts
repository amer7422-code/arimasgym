import { validateEnv } from './env.validation';

const ok = {
  DATABASE_URL: 'postgresql://x',
  JWT_ACCESS_SECRET: 'a'.repeat(32),
  JWT_REFRESH_SECRET: 'b'.repeat(32),
};

describe('validateEnv', () => {
  it('accepts a valid env', () => expect(validateEnv(ok)).toBe(ok));
  it('rejects missing vars', () => expect(() => validateEnv({})).toThrow());
  it('rejects short secrets', () =>
    expect(() => validateEnv({ ...ok, JWT_ACCESS_SECRET: 'short' })).toThrow());
  it('rejects identical secrets', () =>
    expect(() => validateEnv({ ...ok, JWT_REFRESH_SECRET: ok.JWT_ACCESS_SECRET })).toThrow());
});
