import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { Prisma, SubscriptionStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { addDays } from './dates';
import { CreatePlanDto, CreateSubscriptionDto } from './dto/subscriptions.dto';

@Injectable()
export class SubscriptionsService {
  constructor(private prisma: PrismaService) {}

  async createPlan(dto: CreatePlanDto) {
    try {
      return await this.prisma.plan.create({ data: dto });
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === 'P2002') {
        throw new ConflictException('A plan with this name already exists');
      }
      throw e;
    }
  }

  listPlans() {
    return this.prisma.plan.findMany({ where: { isActive: true }, orderBy: { durationDays: 'asc' } });
  }

  // A new subscription starts when the current one ends (renewal), or now if there is none.
  subscribe(dto: CreateSubscriptionDto) {
    return this.prisma.$transaction(
      async (tx) => {
        const [plan, member] = await Promise.all([
          tx.plan.findFirst({ where: { id: dto.planId, isActive: true } }),
          tx.member.findUnique({ where: { id: dto.memberId } }),
        ]);
        if (!plan) throw new NotFoundException('Plan not found');
        if (!member) throw new NotFoundException('Member not found');

        const now = new Date();
        const current = await tx.subscription.findFirst({
          where: { memberId: member.id, status: SubscriptionStatus.ACTIVE, endDate: { gt: now } },
          orderBy: { endDate: 'desc' },
        });
        const startDate = dto.startDate ? new Date(dto.startDate) : (current?.endDate ?? now);
        return tx.subscription.create({
          data: {
            memberId: member.id,
            planId: plan.id,
            startDate,
            endDate: addDays(startDate, plan.durationDays),
          },
          include: { plan: true },
        });
      },
      { isolationLevel: Prisma.TransactionIsolationLevel.Serializable },
    );
  }

  async mine(userId: string) {
    const member = await this.prisma.member.findUnique({ where: { userId } });
    if (!member) throw new NotFoundException('Member profile not found');
    return this.prisma.subscription.findMany({
      where: { memberId: member.id },
      include: { plan: true },
      orderBy: { endDate: 'desc' },
    });
  }

  async cancel(id: string) {
    try {
      return await this.prisma.subscription.update({
        where: { id },
        data: { status: SubscriptionStatus.CANCELLED },
      });
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === 'P2025') {
        throw new NotFoundException('Subscription not found');
      }
      throw e;
    }
  }
}
