import { Body, Controller, Get, Param, ParseUUIDPipe, Patch, Query } from '@nestjs/common';
import { Role } from '@prisma/client';
import { AuthUser } from '../common/auth-user';
import { CurrentUser } from '../common/current-user.decorator';
import { PaginationDto } from '../common/pagination.dto';
import { Roles } from '../auth/roles.decorator';
import { UpdateMemberDto } from './dto/update-member.dto';
import { MembersService } from './members.service';

@Controller('members')
export class MembersController {
  constructor(private members: MembersService) {}

  // "me" routes come first so ":id" never captures them.
  @Get('me')
  me(@CurrentUser() user: AuthUser) {
    return this.members.findByUser(user.id);
  }

  @Patch('me')
  updateMe(@CurrentUser() user: AuthUser, @Body() dto: UpdateMemberDto) {
    return this.members.updateMe(user.id, dto);
  }

  @Roles(Role.ADMIN, Role.TRAINER) @Get()
  findAll(@Query() page: PaginationDto) {
    return this.members.findAll(page);
  }

  @Roles(Role.ADMIN, Role.TRAINER) @Get(':id')
  findOne(@Param('id', ParseUUIDPipe) id: string) {
    return this.members.findOne(id);
  }
}
