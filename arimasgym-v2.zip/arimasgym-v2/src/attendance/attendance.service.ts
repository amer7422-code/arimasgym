import { ConflictException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { SubscriptionStatus } from '@prisma/client';
import { PaginationDto } from '../common/pagination.dto';
import { PrismaService } from '../prisma/prisma.service';

const DUPLICATE_WINDOW_MS = 5 * 60 * 1000;

@Injectable()
export class AttendanceService {
  constructor(private prisma: PrismaService) {}

  async checkIn(memberId: string) {
    const member = await this.prisma.member.findUnique({ where: { id: memberId } });
    if (!member) throw new NotFoundException('Member not found');

    const now = new Date();
    const active = await this.prisma.subscription.findFirst({
      where: {
        memberId,
        status: SubscriptionStatus.ACTIVE,
        startDate: { lte: now },
        endDate: { gt: now },
      },
    });
    if (!active) throw new ForbiddenException('No active subscription');

    const recent = await this.prisma.attendance.findFirst({
      where: { memberId, checkInAt: { gt: new Date(now.getTime() - DUPLICATE_WINDOW_MS) } },
    });
    if (recent) throw new ConflictException('Already checked in a moment ago');

    return this.prisma.attendance.create({ data: { memberId } });
  }

  async mine(userId: string, { page, limit }: PaginationDto) {
    const member = await this.prisma.member.findUnique({ where: { userId } });
    if (!member) throw new NotFoundException('Member profile not found');
    return this.list(page, limit, member.id);
  }

  listAll({ page, limit }: PaginationDto) {
    return this.list(page, limit);
  }

  private async list(page: number, limit: number, memberId?: string) {
    const where = memberId ? { memberId } : {};
    const [items, total] = await this.prisma.$transaction([
      this.prisma.attendance.findMany({
        where,
        orderBy: { checkInAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      this.prisma.attendance.count({ where }),
    ]);
    return { items, total, page, limit };
  }
}
