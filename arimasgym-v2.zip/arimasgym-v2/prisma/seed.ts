import { PrismaClient, Role } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main() {
  const email = process.env.ADMIN_EMAIL;
  const password = process.env.ADMIN_PASSWORD;
  if (!email || !password || password.length < 12) {
    throw new Error('Set ADMIN_EMAIL and ADMIN_PASSWORD (12+ chars) before seeding');
  }
  await prisma.user.upsert({
    where: { email: email.toLowerCase() },
    update: {},
    create: { email: email.toLowerCase(), passwordHash: await bcrypt.hash(password, 12), role: Role.ADMIN },
  });

  const plans = [
    { name: 'Daily', durationDays: 1, price: 5 },
    { name: 'Monthly', durationDays: 30, price: 40 },
    { name: 'Quarterly', durationDays: 90, price: 105 },
    { name: 'Yearly', durationDays: 365, price: 380 },
  ];
  for (const p of plans) {
    await prisma.plan.upsert({ where: { name: p.name }, update: {}, create: p });
  }
}

main().finally(() => prisma.$disconnect());
