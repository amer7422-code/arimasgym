import { addDays } from './dates';

describe('addDays', () => {
  it('adds days without mutating the input', () => {
    const start = new Date('2026-01-31T00:00:00Z');
    expect(addDays(start, 30).toISOString()).toBe('2026-03-02T00:00:00.000Z');
    expect(start.toISOString()).toBe('2026-01-31T00:00:00.000Z');
  });
});
