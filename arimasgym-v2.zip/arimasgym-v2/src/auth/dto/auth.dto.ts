import { Transform } from 'class-transformer';
import { IsEmail, IsNotEmpty, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';

const lower = ({ value }: { value: unknown }) =>
  typeof value === 'string' ? value.trim().toLowerCase() : value;

export class RegisterDto {
  @Transform(lower) @IsEmail() @MaxLength(254)
  email: string;

  // bcrypt only uses the first 72 bytes, so cap the length.
  @IsString() @MinLength(8) @MaxLength(72)
  password: string;

  @IsString() @IsNotEmpty() @MaxLength(100)
  fullName: string;

  @IsOptional() @IsString() @MaxLength(30)
  phone?: string;
}

export class LoginDto {
  @Transform(lower) @IsEmail()
  email: string;

  @IsString() @MaxLength(72)
  password: string;
}

export class RefreshDto {
  @IsString() @IsNotEmpty()
  refreshToken: string;
}
