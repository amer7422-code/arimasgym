import { Body, Controller, Get, Param, ParseUUIDPipe, Patch, Post } from '@nestjs/common';
import { Role } from '@prisma/client';
import { Roles } from '../auth/roles.decorator';
import { AuthUser } from '../common/auth-user';
import { CurrentUser } from '../common/current-user.decorator';
import { CreatePlanDto, CreateSubscriptionDto } from './dto/subscriptions.dto';
import { SubscriptionsService } from './subscriptions.service';

@Controller()
export class SubscriptionsController {
  constructor(private subs: SubscriptionsService) {}

  @Get('plans')
  plans() {
    return this.subs.listPlans();
  }

  @Roles(Role.ADMIN) @Post('plans')
  createPlan(@Body() dto: CreatePlanDto) {
    return this.subs.createPlan(dto);
  }

  @Get('subscriptions/me')
  mine(@CurrentUser() user: AuthUser) {
    return this.subs.mine(user.id);
  }

  @Roles(Role.ADMIN) @Post('subscriptions')
  subscribe(@Body() dto: CreateSubscriptionDto) {
    return this.subs.subscribe(dto);
  }

  @Roles(Role.ADMIN) @Patch('subscriptions/:id/cancel')
  cancel(@Param('id', ParseUUIDPipe) id: string) {
    return this.subs.cancel(id);
  }
}
