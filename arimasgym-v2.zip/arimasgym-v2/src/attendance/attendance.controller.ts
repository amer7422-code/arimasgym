import { Body, Controller, Get, Post, Query } from '@nestjs/common';
import { Role } from '@prisma/client';
import { Roles } from '../auth/roles.decorator';
import { AuthUser } from '../common/auth-user';
import { CurrentUser } from '../common/current-user.decorator';
import { PaginationDto } from '../common/pagination.dto';
import { AttendanceService } from './attendance.service';
import { CheckInDto } from './dto/check-in.dto';

@Controller('attendance')
export class AttendanceController {
  constructor(private attendance: AttendanceService) {}

  @Roles(Role.ADMIN, Role.TRAINER) @Post('check-in')
  checkIn(@Body() dto: CheckInDto) {
    return this.attendance.checkIn(dto.memberId);
  }

  @Get('me')
  mine(@CurrentUser() user: AuthUser, @Query() page: PaginationDto) {
    return this.attendance.mine(user.id, page);
  }

  @Roles(Role.ADMIN, Role.TRAINER) @Get()
  all(@Query() page: PaginationDto) {
    return this.attendance.listAll(page);
  }
}
